<div style="display: flex; flex-direction: column; justify-content: space-between; height: 100vh">
    <div class="pendingBox">
        <h1>Semua Ticket</h1>
        
    </div>
<div>